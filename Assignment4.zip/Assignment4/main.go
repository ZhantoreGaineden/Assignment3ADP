package main

import (
	"log"
	"net/http"
)

func main() {
	app := &App{repo: NewInMemoryCarRepo()}

	mux := http.NewServeMux()
	mux.HandleFunc("/health", app.health)
	mux.HandleFunc("/cars", app.cars)
	mux.HandleFunc("/cars/count", app.carsCount)

	log.Println("Server running on http://localhost:8080")
	log.Fatal(http.ListenAndServe(":8080", mux))
}
