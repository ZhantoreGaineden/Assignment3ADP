package main

import (
	"encoding/json"
	"net/http"
)

type App struct {
	repo CarRepo
}

/* ===== JSON helpers ===== */

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}

func errorJSON(w http.ResponseWriter, status int, msg string) {
	writeJSON(w, status, map[string]string{"error": msg})
}

func readJSON(r *http.Request, dst any) error {
	dec := json.NewDecoder(r.Body)
	dec.DisallowUnknownFields()
	return dec.Decode(dst)
}

/* ===== Handlers ===== */

func (a *App) health(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		errorJSON(w, http.StatusMethodNotAllowed, "method not allowed")
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"status": "ok"})
}

// /cars: GET(list) + POST(create with JSON input)
func (a *App) cars(w http.ResponseWriter, r *http.Request) {
	switch r.Method {
	case http.MethodGet:
		writeJSON(w, http.StatusOK, a.repo.List())

	case http.MethodPost:
		var req struct {
			Brand string  `json:"brand"`
			Model string  `json:"model"`
			Price float64 `json:"price"`
		}

		if err := readJSON(r, &req); err != nil {
			errorJSON(w, http.StatusBadRequest, "invalid json")
			return
		}
		if req.Brand == "" || req.Model == "" || req.Price <= 0 {
			errorJSON(w, http.StatusBadRequest, "brand, model required; price must be > 0")
			return
		}

		created := a.repo.Create(req.Brand, req.Model, req.Price)
		writeJSON(w, http.StatusCreated, created)

	default:
		errorJSON(w, http.StatusMethodNotAllowed, "method not allowed")
	}
}

func (a *App) carsCount(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		errorJSON(w, http.StatusMethodNotAllowed, "method not allowed")
		return
	}
	writeJSON(w, http.StatusOK, map[string]int{"count": a.repo.Count()})
}
