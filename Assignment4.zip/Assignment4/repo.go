package main

import "sync"

type Car struct {
	ID    int     `json:"id"`
	Brand string  `json:"brand"`
	Model string  `json:"model"`
	Price float64 `json:"price"`
}

type CarRepo interface {
	List() []Car
	Create(brand, model string, price float64) Car
	Count() int
}

type InMemoryCarRepo struct {
	mu     sync.RWMutex
	nextID int
	cars   []Car
}

func NewInMemoryCarRepo() *InMemoryCarRepo {
	return &InMemoryCarRepo{nextID: 1, cars: make([]Car, 0)}
}

func (r *InMemoryCarRepo) List() []Car {
	r.mu.RLock()
	defer r.mu.RUnlock()

	out := make([]Car, len(r.cars))
	copy(out, r.cars)
	return out
}

func (r *InMemoryCarRepo) Create(brand, model string, price float64) Car {
	r.mu.Lock()
	defer r.mu.Unlock()

	car := Car{ID: r.nextID, Brand: brand, Model: model, Price: price}
	r.nextID++
	r.cars = append(r.cars, car)
	return car
}

func (r *InMemoryCarRepo) Count() int {
	r.mu.RLock()
	defer r.mu.RUnlock()
	return len(r.cars)
}
